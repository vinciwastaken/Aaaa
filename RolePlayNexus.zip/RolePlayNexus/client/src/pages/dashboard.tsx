import { useQuery } from "@tanstack/react-query";
import StatsGrid from "@/components/dashboard/stats-grid";
import RecentActivity from "@/components/dashboard/recent-activity";
import QuickActions from "@/components/dashboard/quick-actions";

export default function Dashboard() {
  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/dashboard/stats"],
  });

  const { data: tickets, isLoading: ticketsLoading } = useQuery({
    queryKey: ["/api/tickets", "open"],
  });

  const { data: emergencyCalls, isLoading: emergencyLoading } = useQuery({
    queryKey: ["/api/emergency-calls"],
  });

  if (statsLoading || ticketsLoading || emergencyLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-discord"></div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Dashboard Principale</h1>
        <p className="text-gray-600 mt-2">Panoramica completa del sistema CardineBot</p>
      </div>

      <StatsGrid stats={stats} />
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <RecentActivity />
        </div>
        <QuickActions />
      </div>

      {/* Jobs and Active Tickets */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Mestieri Disponibili</h3>
          <div className="grid grid-cols-2 gap-4">
            {[
              { name: 'Poliziotto', icon: '👮‍♂️', active: 12 },
              { name: 'Medico', icon: '👨‍⚕️', active: 8 },
              { name: 'Pompiere', icon: '👨‍🚒', active: 5 },
              { name: 'Meccanico', icon: '🔧', active: 15 },
              { name: 'Camionista', icon: '🚛', active: 23 },
              { name: 'Chef', icon: '👨‍🍳', active: 7 },
              { name: 'Insegnante', icon: '👨‍🏫', active: 4 },
              { name: 'Giornalista', icon: '📰', active: 3 },
            ].map((job) => (
              <div key={job.name} className="bg-gray-50 rounded-lg p-3">
                <div className="flex items-center space-x-2 mb-2">
                  <span className="text-sm">{job.icon}</span>
                  <span className="text-sm font-medium text-gray-900">{job.name}</span>
                </div>
                <p className="text-xs text-gray-600">{job.active} attivi</p>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Ticket di Supporto</h3>
            <span className="bg-red-100 text-red-800 text-xs font-medium px-2.5 py-0.5 rounded-full">
  {Array.isArray(tickets) ? tickets.filter((t: any) => t.priority === 'urgente').length : 0} Urgenti
            </span>
          </div>
          <div className="space-y-4">
{Array.isArray(tickets) ? tickets.slice(0, 3).map((ticket: any) => (
              <div key={ticket.id} className="border border-gray-200 rounded-lg p-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      <span className={`text-xs font-medium px-2 py-1 rounded-full ${
                        ticket.priority === 'urgente' ? 'bg-red-100 text-red-800' :
                        ticket.priority === 'alta' ? 'bg-orange-100 text-orange-800' :
                        ticket.priority === 'media' ? 'bg-yellow-100 text-yellow-800' :
                        'bg-green-100 text-green-800'
                      }`}>
                        {ticket.priority}
                      </span>
                      <span className="text-xs text-gray-500">#{ticket.id.slice(-6)}</span>
                    </div>
                    <h4 className="text-sm font-medium text-gray-900 mb-1">{ticket.title}</h4>
                    <p className="text-xs text-gray-600 mb-2">{ticket.description.slice(0, 60)}...</p>
                    <div className="flex items-center space-x-4 text-xs text-gray-500">
                      <span>{new Date(ticket.createdAt).toLocaleDateString('it-IT')}</span>
                    </div>
                  </div>
                </div>
              </div>
            )) : (
              <div className="text-center text-gray-500 py-4">
                <p>Nessun ticket disponibile</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Command Usage Chart */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Comandi Più Utilizzati</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { name: '/me', icon: '💬', usage: 2341, change: '+15%' },
            { name: '/documento', icon: '📄', usage: 1823, change: '+8%' },
            { name: '/turno', icon: '⏰', usage: 1456, change: '+23%' },
            { name: '/911', icon: '🚨', usage: 987, change: '+5%' },
          ].map((command) => (
            <div key={command.name} className="text-center">
              <div className="bg-blue-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-3">
                <span className="text-xl">{command.icon}</span>
              </div>
              <h4 className="text-sm font-medium text-gray-900 mb-1">{command.name}</h4>
              <p className="text-2xl font-bold text-gray-900">{command.usage.toLocaleString()}</p>
              <p className="text-xs text-gray-500">{command.change} vs ieri</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
