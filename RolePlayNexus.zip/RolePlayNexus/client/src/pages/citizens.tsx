import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Search, Plus, Edit, Trash2, UserCheck, UserX } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface User {
  id: string;
  discordId: string;
  username: string;
  nickname?: string;
  role: string;
  isOnDuty: boolean;
  criminalRecord: {
    arrests: number;
    fines: number;
    totalAmount: number;
    charges: string[];
  };
  createdAt: string;
}

export default function Citizens() {
  const [searchTerm, setSearchTerm] = useState("");
  const [roleFilter, setRoleFilter] = useState("all");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: users, isLoading } = useQuery({
    queryKey: ["/api/users"],
  });

  const createUserMutation = useMutation({
    mutationFn: async (userData: any) => {
      const response = await apiRequest("POST", "/api/users", userData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      setIsCreateDialogOpen(false);
      toast({
        title: "Utente Creato",
        description: "L'utente è stato creato con successo.",
      });
    },
    onError: () => {
      toast({
        title: "Errore",
        description: "Errore nella creazione dell'utente.",
        variant: "destructive",
      });
    },
  });

  const updateUserMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: any }) => {
      const response = await apiRequest("PATCH", `/api/users/${id}`, updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      toast({
        title: "Utente Aggiornato",
        description: "L'utente è stato aggiornato con successo.",
      });
    },
  });

  const getRoleBadge = (role: string) => {
    const roleColors: Record<string, string> = {
      'cittadino': 'bg-gray-100 text-gray-800',
      'poliziotto': 'bg-blue-100 text-blue-800',
      'medico': 'bg-red-100 text-red-800',
      'pompiere': 'bg-orange-100 text-orange-800',
      'meccanico': 'bg-yellow-100 text-yellow-800',
      'amministratore': 'bg-purple-100 text-purple-800',
      'super_admin': 'bg-black text-white',
    };
    
    return roleColors[role] || 'bg-gray-100 text-gray-800';
  };

  const getRoleEmoji = (role: string) => {
    const roleEmojis: Record<string, string> = {
      'cittadino': '👤',
      'poliziotto': '👮‍♂️',
      'medico': '👨‍⚕️',
      'pompiere': '👨‍🚒',
      'meccanico': '🔧',
      'camionista': '🚛',
      'chef': '👨‍🍳',
      'amministratore': '⚙️',
      'super_admin': '👑',
    };
    
    return roleEmojis[role] || '👤';
  };

const filteredUsers = Array.isArray(users) ? users.filter((user: User) => {
    const matchesSearch = user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         user.nickname?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRole = roleFilter === "all" || user.role === roleFilter;
    return matchesSearch && matchesRole;
  }) : [];

  const handleCreateUser = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    
    const userData = {
      discordId: formData.get('discordId') as string,
      username: formData.get('username') as string,
      nickname: formData.get('nickname') as string,
      role: formData.get('role') as string,
    };

    createUserMutation.mutate(userData);
  };

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/4"></div>
          <div className="h-64 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Gestione Cittadini</h1>
          <p className="text-gray-600 mt-2">Database utenti e informazioni personali</p>
        </div>
        
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button className="discord-btn">
              <Plus className="w-4 h-4 mr-2" />
              Nuovo Cittadino
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Crea Nuovo Cittadino</DialogTitle>
              <DialogDescription>
                Aggiungi un nuovo cittadino al database del server.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleCreateUser} className="space-y-4">
              <div>
                <Label htmlFor="discordId">Discord ID</Label>
                <Input
                  id="discordId"
                  name="discordId"
                  required
                  placeholder="123456789012345678"
                />
              </div>
              <div>
                <Label htmlFor="username">Username Discord</Label>
                <Input
                  id="username"
                  name="username"
                  required
                  placeholder="marco_rossi"
                />
              </div>
              <div>
                <Label htmlFor="nickname">Nickname RP</Label>
                <Input
                  id="nickname"
                  name="nickname"
                  placeholder="Marco Rossi"
                />
              </div>
              <div>
                <Label htmlFor="role">Ruolo</Label>
                <Select name="role" required>
                  <SelectTrigger>
                    <SelectValue placeholder="Seleziona ruolo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="cittadino">Cittadino</SelectItem>
                    <SelectItem value="poliziotto">Poliziotto</SelectItem>
                    <SelectItem value="medico">Medico</SelectItem>
                    <SelectItem value="pompiere">Pompiere</SelectItem>
                    <SelectItem value="meccanico">Meccanico</SelectItem>
                    <SelectItem value="camionista">Camionista</SelectItem>
                    <SelectItem value="chef">Chef</SelectItem>
                    <SelectItem value="amministratore">Amministratore</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex justify-end space-x-2">
                <Button 
                  type="button" 
                  variant="outline"
                  onClick={() => setIsCreateDialogOpen(false)}
                >
                  Annulla
                </Button>
                <Button 
                  type="submit" 
                  disabled={createUserMutation.isPending}
                  className="discord-btn"
                >
                  Crea Cittadino
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Cittadini Totali</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{Array.isArray(users) ? users.length : 0}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">In Servizio</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
{Array.isArray(users) ? users.filter((u: User) => u.isOnDuty).length : 0}
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Con Fedina Sporca</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
{Array.isArray(users) ? users.filter((u: User) => u.criminalRecord?.arrests > 0).length : 0}
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Staff</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">
{Array.isArray(users) ? users.filter((u: User) => ['amministratore', 'super_admin'].includes(u.role)).length : 0}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Cerca per username o nickname..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        
        <Select value={roleFilter} onValueChange={setRoleFilter}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="Filtra per ruolo" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tutti i ruoli</SelectItem>
            <SelectItem value="cittadino">Cittadino</SelectItem>
            <SelectItem value="poliziotto">Poliziotto</SelectItem>
            <SelectItem value="medico">Medico</SelectItem>
            <SelectItem value="pompiere">Pompiere</SelectItem>
            <SelectItem value="meccanico">Meccanico</SelectItem>
            <SelectItem value="amministratore">Amministratore</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Users Table */}
      <Card>
        <CardHeader>
          <CardTitle>Lista Cittadini</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Cittadino</TableHead>
                <TableHead>Ruolo</TableHead>
                <TableHead>Stato</TableHead>
                <TableHead>Fedina Penale</TableHead>
                <TableHead>Registrato</TableHead>
                <TableHead>Azioni</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredUsers.map((user: User) => (
                <TableRow key={user.id}>
                  <TableCell>
                    <div className="flex items-center space-x-3">
                      <Avatar>
                        <AvatarFallback>
                          {getRoleEmoji(user.role)}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="font-medium">
                          {user.nickname || user.username}
                        </div>
                        <div className="text-sm text-gray-500">
                          @{user.username}
                        </div>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge className={getRoleBadge(user.role)}>
                      {user.role}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      {user.isOnDuty ? (
                        <>
                          <div className="status-online"></div>
                          <span className="text-green-600 text-sm">In servizio</span>
                        </>
                      ) : (
                        <>
                          <div className="status-offline"></div>
                          <span className="text-gray-500 text-sm">Fuori servizio</span>
                        </>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="text-sm">
                      <div>Arresti: {user.criminalRecord.arrests}</div>
                      <div>Multe: €{user.criminalRecord.totalAmount}</div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="text-sm text-gray-500">
                      {new Date(user.createdAt).toLocaleDateString('it-IT')}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => updateUserMutation.mutate({
                          id: user.id,
                          updates: { isOnDuty: !user.isOnDuty }
                        })}
                      >
                        {user.isOnDuty ? <UserX className="w-4 h-4" /> : <UserCheck className="w-4 h-4" />}
                      </Button>
                      <Button size="sm" variant="outline">
                        <Edit className="w-4 h-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
