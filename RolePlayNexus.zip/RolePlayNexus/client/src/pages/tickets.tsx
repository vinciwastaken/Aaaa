import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { 
  Search, 
  Plus, 
  Ticket, 
  Clock, 
  CheckCircle, 
  XCircle,
  AlertTriangle,
  User
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface TicketType {
  id: string;
  userId: string;
  title: string;
  description: string;
  status: 'aperto' | 'in_corso' | 'risolto' | 'chiuso';
  priority: 'bassa' | 'media' | 'alta' | 'urgente';
  assignedTo?: string;
  createdAt: string;
  updatedAt: string;
}

interface User {
  id: string;
  username: string;
  nickname?: string;
}

export default function Tickets() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [priorityFilter, setPriorityFilter] = useState("all");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [selectedTicket, setSelectedTicket] = useState<TicketType | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: tickets, isLoading } = useQuery({
    queryKey: ["/api/tickets"],
  });

  const { data: users } = useQuery({
    queryKey: ["/api/users"],
  });

  const createTicketMutation = useMutation({
    mutationFn: async (ticketData: any) => {
      const response = await apiRequest("POST", "/api/tickets", ticketData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tickets"] });
      setIsCreateDialogOpen(false);
      toast({
        title: "Ticket Creato",
        description: "Il ticket è stato creato con successo.",
      });
    },
    onError: () => {
      toast({
        title: "Errore",
        description: "Errore nella creazione del ticket.",
        variant: "destructive",
      });
    },
  });

  const updateTicketMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: any }) => {
      const response = await apiRequest("PATCH", `/api/tickets/${id}`, updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tickets"] });
      setSelectedTicket(null);
      toast({
        title: "Ticket Aggiornato",
        description: "Il ticket è stato aggiornato con successo.",
      });
    },
  });

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      'aperto': { color: 'bg-red-100 text-red-800', icon: '🔴', text: 'Aperto' },
      'in_corso': { color: 'bg-yellow-100 text-yellow-800', icon: '🟡', text: 'In Corso' },
      'risolto': { color: 'bg-green-100 text-green-800', icon: '🟢', text: 'Risolto' },
      'chiuso': { color: 'bg-gray-100 text-gray-800', icon: '⚫', text: 'Chiuso' },
    };
    
    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.aperto;
    
    return (
      <Badge className={config.color}>
        {config.icon} {config.text}
      </Badge>
    );
  };

  const getPriorityBadge = (priority: string) => {
    const priorityConfig = {
      'bassa': 'priority-low',
      'media': 'priority-medium', 
      'alta': 'priority-high',
      'urgente': 'priority-urgent',
    };
    
    const className = priorityConfig[priority as keyof typeof priorityConfig] || 'priority-medium';
    
    return (
      <span className={className}>
        {priority.toUpperCase()}
      </span>
    );
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'aperto':
        return <XCircle className="w-4 h-4 text-red-600" />;
      case 'in_corso':
        return <Clock className="w-4 h-4 text-yellow-600" />;
      case 'risolto':
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'chiuso':
        return <CheckCircle className="w-4 h-4 text-gray-600" />;
      default:
        return <XCircle className="w-4 h-4 text-red-600" />;
    }
  };

const filteredTickets = Array.isArray(tickets) ? tickets.filter((ticket: TicketType) => {
    const matchesSearch = ticket.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         ticket.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === "all" || ticket.status === statusFilter;
    const matchesPriority = priorityFilter === "all" || ticket.priority === priorityFilter;
    return matchesSearch && matchesStatus && matchesPriority;
  }) : [];

  const handleCreateTicket = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    
    const ticketData = {
      userId: formData.get('userId') as string,
      title: formData.get('title') as string,
      description: formData.get('description') as string,
      priority: formData.get('priority') as string,
    };

    createTicketMutation.mutate(ticketData);
  };

  const handleUpdateTicketStatus = (ticketId: string, status: string) => {
    updateTicketMutation.mutate({
      id: ticketId,
      updates: { status }
    });
  };

  const handleAssignTicket = (ticketId: string, assignedTo: string) => {
    updateTicketMutation.mutate({
      id: ticketId,
      updates: { assignedTo, status: 'in_corso' }
    });
  };

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/4"></div>
          <div className="h-64 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

const stats = {
    total: Array.isArray(tickets) ? tickets.length : 0,
    open: Array.isArray(tickets) ? tickets.filter((t: TicketType) => t.status === 'aperto').length : 0,
    inProgress: Array.isArray(tickets) ? tickets.filter((t: TicketType) => t.status === 'in_corso').length : 0,
    resolved: Array.isArray(tickets) ? tickets.filter((t: TicketType) => t.status === 'risolto').length : 0,
    urgent: Array.isArray(tickets) ? tickets.filter((t: TicketType) => t.priority === 'urgente').length : 0,
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Sistema Ticket</h1>
          <p className="text-gray-600 mt-2">Supporto tecnico e assistenza utenti</p>
        </div>
        
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button className="discord-btn">
              <Plus className="w-4 h-4 mr-2" />
              Nuovo Ticket
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Crea Nuovo Ticket</DialogTitle>
              <DialogDescription>
                Crea un nuovo ticket di supporto per assistenza tecnica.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleCreateTicket} className="space-y-4">
              <div>
                <Label htmlFor="userId">Utente</Label>
                <Select name="userId" required>
                  <SelectTrigger>
                    <SelectValue placeholder="Seleziona utente" />
                  </SelectTrigger>
                  <SelectContent>
{Array.isArray(users) ? users.map((user: User) => (
                      <SelectItem key={user.id} value={user.id}>
                        {user.nickname || user.username}
                      </SelectItem>
                    )) : null}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="title">Titolo</Label>
                <Input
                  id="title"
                  name="title"
                  required
                  placeholder="Problema con comando /arresto"
                />
              </div>
              <div>
                <Label htmlFor="description">Descrizione</Label>
                <Textarea
                  id="description"
                  name="description"
                  required
                  placeholder="Descrivi il problema nel dettaglio..."
                  rows={4}
                />
              </div>
              <div>
                <Label htmlFor="priority">Priorità</Label>
                <Select name="priority" required>
                  <SelectTrigger>
                    <SelectValue placeholder="Seleziona priorità" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="bassa">Bassa</SelectItem>
                    <SelectItem value="media">Media</SelectItem>
                    <SelectItem value="alta">Alta</SelectItem>
                    <SelectItem value="urgente">Urgente</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex justify-end space-x-2">
                <Button 
                  type="button" 
                  variant="outline"
                  onClick={() => setIsCreateDialogOpen(false)}
                >
                  Annulla
                </Button>
                <Button 
                  type="submit" 
                  disabled={createTicketMutation.isPending}
                  className="discord-btn"
                >
                  Crea Ticket
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center">
              <Ticket className="w-4 h-4 mr-2" />
              Ticket Totali
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center">
              <XCircle className="w-4 h-4 mr-2 text-red-600" />
              Aperti
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{stats.open}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center">
              <Clock className="w-4 h-4 mr-2 text-yellow-600" />
              In Corso
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{stats.inProgress}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center">
              <CheckCircle className="w-4 h-4 mr-2 text-green-600" />
              Risolti
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.resolved}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center">
              <AlertTriangle className="w-4 h-4 mr-2 text-red-600" />
              Urgenti
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{stats.urgent}</div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Cerca per titolo o descrizione..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="Filtra per stato" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tutti gli stati</SelectItem>
            <SelectItem value="aperto">Aperti</SelectItem>
            <SelectItem value="in_corso">In Corso</SelectItem>
            <SelectItem value="risolto">Risolti</SelectItem>
            <SelectItem value="chiuso">Chiusi</SelectItem>
          </SelectContent>
        </Select>

        <Select value={priorityFilter} onValueChange={setPriorityFilter}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="Filtra per priorità" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tutte le priorità</SelectItem>
            <SelectItem value="urgente">Urgente</SelectItem>
            <SelectItem value="alta">Alta</SelectItem>
            <SelectItem value="media">Media</SelectItem>
            <SelectItem value="bassa">Bassa</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Tickets Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredTickets.map((ticket: TicketType) => {
const user = Array.isArray(users) ? users.find((u: User) => u.id === ticket.userId) : null;
          const assignedUser = ticket.assignedTo && Array.isArray(users) ? users.find((u: User) => u.id === ticket.assignedTo) : null;
          
          return (
            <Card key={ticket.id} className="cursor-pointer hover:shadow-md transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      {getPriorityBadge(ticket.priority)}
                      <span className="text-xs text-gray-500">#{ticket.id.slice(-6)}</span>
                    </div>
                    <CardTitle className="text-base font-medium mb-1">
                      {ticket.title}
                    </CardTitle>
                    <p className="text-sm text-gray-600 line-clamp-2">
                      {ticket.description}
                    </p>
                  </div>
                  <div className="flex items-center space-x-2">
                    {getStatusIcon(ticket.status)}
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="flex items-center justify-between text-xs text-gray-500 mb-3">
                  <div className="flex items-center space-x-2">
                    <User className="w-3 h-3" />
                    <span>{user?.nickname || user?.username || 'N/D'}</span>
                  </div>
                  <span>{new Date(ticket.createdAt).toLocaleDateString('it-IT')}</span>
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    {getStatusBadge(ticket.status)}
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    {ticket.status === 'aperto' && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleUpdateTicketStatus(ticket.id, 'in_corso')}
                      >
                        Prendi in Carico
                      </Button>
                    )}
                    {ticket.status === 'in_corso' && (
                      <Button
                        size="sm"
                        className="bg-green-600 hover:bg-green-700 text-white"
                        onClick={() => handleUpdateTicketStatus(ticket.id, 'risolto')}
                      >
                        Risolvi
                      </Button>
                    )}
                    {ticket.status === 'risolto' && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleUpdateTicketStatus(ticket.id, 'chiuso')}
                      >
                        Chiudi
                      </Button>
                    )}
                  </div>
                </div>

                {assignedUser && (
                  <div className="mt-3 pt-3 border-t border-gray-100">
                    <div className="text-xs text-gray-500">
                      Assegnato a: <span className="font-medium">{assignedUser.nickname || assignedUser.username}</span>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {filteredTickets.length === 0 && (
        <Card>
          <CardContent className="text-center py-8">
            <Ticket className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500">Nessun ticket trovato</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
