import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Search, Plus, Car, ShieldCheck, ShieldX, Ban } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface Vehicle {
  id: string;
  ownerId: string;
  name: string;
  licensePlate: string;
  insuranceExpiry?: string;
  isSeized: boolean;
  seizedBy?: string;
  seizedReason?: string;
  createdAt: string;
}

interface User {
  id: string;
  username: string;
  nickname?: string;
}

export default function Vehicles() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [selectedOwnerId, setSelectedOwnerId] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: users } = useQuery({
    queryKey: ["/api/users"],
  });

  const { data: vehicles, isLoading } = useQuery({
    queryKey: ["/api/vehicles"],
    enabled: !!selectedOwnerId,
    queryFn: async () => {
      if (!selectedOwnerId) return [];
      const response = await fetch(`/api/vehicles?ownerId=${selectedOwnerId}`);
      return response.json();
    },
  });

  const createVehicleMutation = useMutation({
    mutationFn: async (vehicleData: any) => {
      const response = await apiRequest("POST", "/api/vehicles", vehicleData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/vehicles"] });
      setIsCreateDialogOpen(false);
      toast({
        title: "Veicolo Registrato",
        description: "Il veicolo è stato registrato con successo.",
      });
    },
    onError: () => {
      toast({
        title: "Errore",
        description: "Errore nella registrazione del veicolo.",
        variant: "destructive",
      });
    },
  });

  const seizeVehicleMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: any }) => {
      const response = await apiRequest("PATCH", `/api/vehicles/${id}/seize`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/vehicles"] });
      toast({
        title: "Veicolo Sequestrato",
        description: "Il veicolo è stato sequestrato con successo.",
      });
    },
  });

  const getStatusBadge = (vehicle: Vehicle) => {
    if (vehicle.isSeized) {
      return <Badge className="bg-red-100 text-red-800">🚫 Sequestrato</Badge>;
    }
    
    const hasValidInsurance = vehicle.insuranceExpiry && 
      new Date(vehicle.insuranceExpiry) > new Date();
    
    if (hasValidInsurance) {
      return <Badge className="bg-green-100 text-green-800">✅ Disponibile</Badge>;
    } else {
      return <Badge className="bg-yellow-100 text-yellow-800">⚠️ Assicurazione Scaduta</Badge>;
    }
  };

  const getInsuranceStatus = (vehicle: Vehicle) => {
    if (!vehicle.insuranceExpiry) {
      return <span className="text-red-600">❌ Non assicurato</span>;
    }
    
    const expiryDate = new Date(vehicle.insuranceExpiry);
    const now = new Date();
    
    if (expiryDate > now) {
      return (
        <span className="text-green-600">
          ✅ Valida fino al {expiryDate.toLocaleDateString('it-IT')}
        </span>
      );
    } else {
      return <span className="text-red-600">❌ Scaduta</span>;
    }
  };

  const filteredVehicles = vehicles?.filter((vehicle: Vehicle) => {
    const matchesSearch = vehicle.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         vehicle.licensePlate.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === "all" || 
      (statusFilter === "seized" && vehicle.isSeized) ||
      (statusFilter === "available" && !vehicle.isSeized) ||
      (statusFilter === "expired" && vehicle.insuranceExpiry && new Date(vehicle.insuranceExpiry) < new Date());
    
    return matchesSearch && matchesStatus;
  }) || [];

  const handleCreateVehicle = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    
    const vehicleData = {
      ownerId: formData.get('ownerId') as string,
      name: formData.get('name') as string,
      licensePlate: formData.get('licensePlate') as string,
    };

    createVehicleMutation.mutate(vehicleData);
  };

  const handleSeizeVehicle = (vehicleId: string) => {
    const reason = prompt("Inserisci il motivo del sequestro:");
    if (reason) {
      seizeVehicleMutation.mutate({
        id: vehicleId,
        data: {
          seizedBy: "current-user-id", // This would come from auth context
          reason
        }
      });
    }
  };

const allVehicles = Array.isArray(users) ? users.flatMap((user: User) => 
    // This would need to be fetched properly in a real app
    [] // vehicles for each user
  ) : [];

  if (isLoading && selectedOwnerId) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/4"></div>
          <div className="h-64 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Gestione Veicoli</h1>
          <p className="text-gray-600 mt-2">Database veicoli, assicurazioni e libretti</p>
        </div>
        
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button className="discord-btn">
              <Plus className="w-4 h-4 mr-2" />
              Registra Veicolo
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Registra Nuovo Veicolo</DialogTitle>
              <DialogDescription>
                Registra un nuovo veicolo nel database del server.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleCreateVehicle} className="space-y-4">
              <div>
                <Label htmlFor="ownerId">Proprietario</Label>
                <Select name="ownerId" required>
                  <SelectTrigger>
                    <SelectValue placeholder="Seleziona proprietario" />
                  </SelectTrigger>
                  <SelectContent>
{Array.isArray(users) ? users.map((user: User) => (
                      <SelectItem key={user.id} value={user.id}>
                        {user.nickname || user.username}
                      </SelectItem>
                    )) : null}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="name">Nome/Modello Veicolo</Label>
                <Input
                  id="name"
                  name="name"
                  required
                  placeholder="BMW X5"
                />
              </div>
              <div>
                <Label htmlFor="licensePlate">Targa</Label>
                <Input
                  id="licensePlate"
                  name="licensePlate"
                  required
                  placeholder="AB123CD"
                  style={{ textTransform: 'uppercase' }}
                />
              </div>
              <div className="flex justify-end space-x-2">
                <Button 
                  type="button" 
                  variant="outline"
                  onClick={() => setIsCreateDialogOpen(false)}
                >
                  Annulla
                </Button>
                <Button 
                  type="submit" 
                  disabled={createVehicleMutation.isPending}
                  className="discord-btn"
                >
                  Registra Veicolo
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center">
              <Car className="w-4 h-4 mr-2" />
              Veicoli Totali
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{allVehicles.length}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center">
              <ShieldCheck className="w-4 h-4 mr-2 text-green-600" />
              Assicurati
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {allVehicles.filter((v: Vehicle) => 
                v.insuranceExpiry && new Date(v.insuranceExpiry) > new Date()
              ).length}
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center">
              <Ban className="w-4 h-4 mr-2 text-red-600" />
              Sequestrati
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              {allVehicles.filter((v: Vehicle) => v.isSeized).length}
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center">
              <ShieldX className="w-4 h-4 mr-2 text-yellow-600" />
              Assicurazione Scaduta
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">
              {allVehicles.filter((v: Vehicle) => 
                !v.insuranceExpiry || new Date(v.insuranceExpiry) < new Date()
              ).length}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Cerca per nome veicolo o targa..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="Filtra per stato" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tutti i veicoli</SelectItem>
            <SelectItem value="available">Disponibili</SelectItem>
            <SelectItem value="seized">Sequestrati</SelectItem>
            <SelectItem value="expired">Assicurazione scaduta</SelectItem>
          </SelectContent>
        </Select>

        <Select value={selectedOwnerId} onValueChange={setSelectedOwnerId}>
          <SelectTrigger className="w-64">
            <SelectValue placeholder="Seleziona proprietario" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="">Tutti i proprietari</SelectItem>
{Array.isArray(users) ? users.map((user: User) => (
              <SelectItem key={user.id} value={user.id}>
                {user.nickname || user.username}
              </SelectItem>
            )) : null}
          </SelectContent>
        </Select>
      </div>

      {/* Vehicles Table */}
      <Card>
        <CardHeader>
          <CardTitle>Lista Veicoli</CardTitle>
        </CardHeader>
        <CardContent>
          {!selectedOwnerId ? (
            <div className="text-center py-8 text-gray-500">
              Seleziona un proprietario per visualizzare i suoi veicoli
            </div>
          ) : filteredVehicles.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              Nessun veicolo trovato per questo proprietario
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Veicolo</TableHead>
                  <TableHead>Proprietario</TableHead>
                  <TableHead>Stato</TableHead>
                  <TableHead>Assicurazione</TableHead>
                  <TableHead>Registrato</TableHead>
                  <TableHead>Azioni</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredVehicles.map((vehicle: Vehicle) => {
const owner = Array.isArray(users) ? users.find((u: User) => u.id === vehicle.ownerId) : null;
                  
                  return (
                    <TableRow key={vehicle.id}>
                      <TableCell>
                        <div>
                          <div className="font-medium">{vehicle.name}</div>
                          <div className="text-sm text-gray-500">{vehicle.licensePlate}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="font-medium">
                          {owner?.nickname || owner?.username || 'N/D'}
                        </div>
                      </TableCell>
                      <TableCell>
                        {getStatusBadge(vehicle)}
                      </TableCell>
                      <TableCell>
                        {getInsuranceStatus(vehicle)}
                      </TableCell>
                      <TableCell>
                        <div className="text-sm text-gray-500">
                          {new Date(vehicle.createdAt).toLocaleDateString('it-IT')}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          {!vehicle.isSeized && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleSeizeVehicle(vehicle.id)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <Ban className="w-4 h-4" />
                              Sequestra
                            </Button>
                          )}
                          {vehicle.isSeized && (
                            <Button
                              size="sm"
                              variant="outline"
                              className="text-green-600 hover:text-green-700"
                            >
                              Libera
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
