import { Link, useLocation } from "wouter";
import { 
  LayoutDashboard, 
  Users, 
  UserCheck, 
  Briefcase, 
  Drama, 
  FileText, 
  Car, 
  LockOpen, 
  AlertTriangle, 
  Pill, 
  Ticket, 
  Settings,
  Bot,
  TrendingUp
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";

interface SidebarProps {
  children: React.ReactNode;
}

interface NavItem {
  name: string;
  href: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: number;
}

interface NavSection {
  title: string;
  items: NavItem[];
}

export default function Layout({ children }: SidebarProps) {
  const [location] = useLocation();
  
  const { data: stats } = useQuery({
    queryKey: ["/api/dashboard/stats"],
    refetchInterval: 30000,
  });

  const { data: tickets } = useQuery({
    queryKey: ["/api/tickets", "open"],
    refetchInterval: 10000,
  });

  const navSections: NavSection[] = [
    {
      title: "",
      items: [
        { name: "Dashboard", href: "/", icon: LayoutDashboard },
      ]
    },
    {
      title: "Gestione Utenti",
      items: [
        { name: "Cittadini", href: "/citizens", icon: Users },
        { name: "Ruoli & Permessi", href: "/roles", icon: UserCheck },
        { name: "Mestieri & Lavori", href: "/jobs", icon: Briefcase },
      ]
    },
    {
      title: "Sistema RP",
      items: [
        { name: "Controllo RP", href: "/roleplay", icon: Drama },
        { name: "Documenti", href: "/documents", icon: FileText },
        { name: "Veicoli", href: "/vehicles", icon: Car },
      ]
    },
    {
      title: "Sistema Polizia",
      items: [
        { name: "Arresti & Multe", href: "/arrests", icon: LockOpen },
        { name: "Crimini & Rapine", href: "/crimes", icon: AlertTriangle },
        { name: "Sistema Droghe", href: "/drugs", icon: Pill },
      ]
    },
    {
      title: "Supporto",
      items: [
        { 
          name: "Sistema Ticket", 
          href: "/tickets", 
          icon: Ticket,
badge: Array.isArray(tickets) ? tickets.filter((t: any) => t.priority === 'urgente').length : 0
        },
        { name: "Impostazioni", href: "/settings", icon: Settings },
      ]
    },
  ];

  return (
    <div className="flex h-screen overflow-hidden">
      {/* Sidebar */}
      <div className="w-64 bg-sidebar text-white flex-shrink-0 shadow-xl">
        {/* Header */}
        <div className="p-6 border-b border-gray-700">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-discord rounded-lg flex items-center justify-center">
              <Bot className="text-white text-lg" />
            </div>
            <div>
              <h1 className="text-xl font-bold">CardineBot</h1>
              <p className="text-gray-400 text-sm">Management Panel</p>
            </div>
          </div>
        </div>

        {/* Bot Status */}
        <div className="p-4 border-b border-gray-700">
          <h3 className="sidebar-category">Status Bot</h3>
          
          <div className="space-y-2">
            <div className="bg-gray-800 rounded-lg p-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className="status-online"></div>
                  <span className="text-sm font-medium">Bot Cittadini</span>
                </div>
                <span className="text-xs text-green-400">Online</span>
              </div>
              <div className="text-xs text-gray-400 mt-1">
                <span>12h 34m</span> • <span>{stats?.totalUsers || 0} utenti</span>
              </div>
            </div>

            <div className="bg-gray-800 rounded-lg p-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className="status-online"></div>
                  <span className="text-sm font-medium">Bot Polizia/Admin</span>
                </div>
                <span className="text-xs text-green-400">Online</span>
              </div>
              <div className="text-xs text-gray-400 mt-1">
                <span>12h 34m</span> • <span>{stats?.commandsExecuted || 0} comandi/h</span>
              </div>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto py-4 scrollbar-hide">
          <div className="px-4 space-y-1">
            {navSections.map((section, sectionIndex) => (
              <div key={sectionIndex}>
                {section.title && (
                  <h3 className="sidebar-category">{section.title}</h3>
                )}
                {section.items.map((item) => {
                  const isActive = location === item.href || 
                    (item.href !== "/" && location.startsWith(item.href));
                  
                  return (
                    <Link
                      key={item.name}
                      href={item.href}
                      className={`sidebar-item ${isActive ? 'active' : ''}`}
                    >
                      <item.icon className="mr-3 text-sm" />
                      {item.name}
                      {item.badge && item.badge > 0 && (
                        <span className="ml-auto bg-red-500 text-white text-xs rounded-full px-2 py-1">
                          {item.badge}
                        </span>
                      )}
                    </Link>
                  );
                })}
              </div>
            ))}
          </div>
        </nav>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <main className="flex-1 overflow-y-auto bg-gray-50">
          {children}
        </main>
      </div>
    </div>
  );
}
