import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { 
  User, 
  AlertTriangle, 
  Car, 
  LockOpen, 
  Pill,
  Clock
} from "lucide-react";

interface Activity {
  id: string;
  type: string;
  user: string;
  action: string;
  details?: string;
  timestamp: string;
}

export default function RecentActivity() {
  const { data: activities, isLoading } = useQuery({
    queryKey: ["/api/activities"],
    refetchInterval: 30000,
  });

  // Mock activities for demonstration - in production this would come from the API
  const mockActivities: Activity[] = [
    {
      id: "1",
      type: "work",
      user: "Marco_Rossi",
      action: "ha eseguito il comando",
      details: "/turno @poliziotto inizio",
      timestamp: "2 minuti fa"
    },
    {
      id: "2",
      type: "crime",
      user: "Luca_Bianchi",
      action: "ha segnalato una rapina con",
      details: "/rapina banca-centrale",
      timestamp: "5 minuti fa"
    },
    {
      id: "3",
      type: "vehicle",
      user: "Admin_System",
      action: "ha registrato un nuovo veicolo",
      details: "BMW X5 - ABC123",
      timestamp: "8 minuti fa"
    },
    {
      id: "4",
      type: "arrest",
      user: "Poliziotto_Mario",
      action: "ha arrestato",
      details: "Giovanni_Neri per traffico di droga",
      timestamp: "12 minuti fa"
    },
    {
      id: "5",
      type: "drug",
      user: "Andrea_Verdi",
      action: "ha iniziato la raccolta di",
      details: "marijuana",
      timestamp: "15 minuti fa"
    },
  ];

  const getActivityIcon = (type: string) => {
    switch (type) {
      case "work":
        return <User className="text-blue-600" />;
      case "crime":
        return <AlertTriangle className="text-red-600" />;
      case "vehicle":
        return <Car className="text-green-600" />;
      case "arrest":
        return <LockOpen className="text-yellow-600" />;
      case "drug":
        return <Pill className="text-purple-600" />;
      default:
        return <Clock className="text-gray-600" />;
    }
  };

  const getActivityBgColor = (type: string) => {
    switch (type) {
      case "work":
        return "bg-blue-100";
      case "crime":
        return "bg-red-100";
      case "vehicle":
        return "bg-green-100";
      case "arrest":
        return "bg-yellow-100";
      case "drug":
        return "bg-purple-100";
      default:
        return "bg-gray-100";
    }
  };

  if (isLoading) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-100">
        <div className="p-6 border-b border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900">Attività Recenti</h3>
        </div>
        <div className="p-6">
          <div className="animate-pulse space-y-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="flex items-start space-x-3">
                <div className="w-8 h-8 bg-gray-200 rounded-full"></div>
                <div className="flex-1">
                  <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const displayActivities = activities || mockActivities;

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100">
      <div className="p-6 border-b border-gray-100">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-gray-900">Attività Recenti</h3>
          <Button variant="ghost" size="sm" className="text-blue-600 hover:text-blue-700">
            Vedi tutto
          </Button>
        </div>
      </div>
      <div className="p-6">
        <div className="space-y-4">
{Array.isArray(displayActivities) ? displayActivities.slice(0, 5).map((activity: any) => (
            <div key={activity.id} className="flex items-start space-x-3">
              <div className={`flex-shrink-0 w-8 h-8 ${getActivityBgColor(activity.type)} rounded-full flex items-center justify-center`}>
                {getActivityIcon(activity.type)}
              </div>
              <div className="flex-1">
                <p className="text-sm text-gray-900">
                  <span className="font-medium">{activity.user}</span>{" "}
                  {activity.action}{" "}
                  {activity.details && (
                    <span className="font-mono bg-gray-100 px-1 rounded text-xs">
                      {activity.details}
                    </span>
                  )}
                </p>
                <p className="text-xs text-gray-500 mt-1">{activity.timestamp}</p>
              </div>
            </div>
          )) : (
            <div className="text-center text-gray-500 py-4">
              <p>Nessuna attività recente</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
