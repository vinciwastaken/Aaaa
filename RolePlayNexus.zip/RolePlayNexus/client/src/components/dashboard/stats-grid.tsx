import { TrendingUp, Users, Terminal, Ticket, Drama } from "lucide-react";

interface StatsGridProps {
  stats: any;
}

export default function StatsGrid({ stats }: StatsGridProps) {
  const statCards = [
    {
      title: "Utenti Attivi",
      value: stats?.activeUsers || 0,
      total: stats?.totalUsers || 0,
      change: "+12% da ieri",
      changeType: "positive" as const,
      icon: Users,
      color: "blue",
    },
    {
      title: "Comandi Eseguiti",
      value: stats?.commandsExecuted || 0,
      change: "+5% da ieri",
      changeType: "positive" as const,
      icon: Terminal,
      color: "green",
    },
    {
      title: "Ticket Aperti",
      value: stats?.openTickets || 0,
      change: "+3 nuovi",
      changeType: "negative" as const,
      icon: Ticket,
      color: "red",
    },
    {
      title: "Modalità RP",
      value: "ATTIVA",
      subtitle: "Da 2h 15m",
      icon: Drama,
      color: "purple",
    },
  ];

  const getColorClasses = (color: string) => {
    const colors = {
      blue: "bg-blue-100 text-blue-600",
      green: "bg-green-100 text-green-600",
      red: "bg-red-100 text-red-600",
      purple: "bg-purple-100 text-purple-600",
    };
    return colors[color as keyof typeof colors] || colors.blue;
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {statCards.map((stat, index) => (
        <div key={index} className="stat-card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm font-medium">{stat.title}</p>
              <p className="text-3xl font-bold text-gray-900 mt-1">
                {typeof stat.value === 'number' ? stat.value.toLocaleString() : stat.value}
              </p>
              {stat.change && (
                <p className={`text-xs mt-1 ${
                  stat.changeType === 'positive' ? 'text-green-600' : 
                  stat.changeType === 'negative' ? 'text-red-600' : 
                  'text-gray-600'
                }`}>
                  {stat.changeType === 'positive' && <TrendingUp className="inline w-3 h-3 mr-1" />}
                  {stat.change}
                </p>
              )}
              {stat.subtitle && (
                <p className="text-xs text-gray-600 mt-1">{stat.subtitle}</p>
              )}
            </div>
            <div className={`rounded-lg p-3 ${getColorClasses(stat.color)}`}>
              <stat.icon className="text-xl" />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
