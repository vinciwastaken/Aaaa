import { Button } from "@/components/ui/button";
import { 
  Drama, 
  Megaphone, 
  BarChart3, 
  AlertTriangle,
  Activity,
  Database,
  TrendingUp
} from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

export default function QuickActions() {
  const { toast } = useToast();
  const [isRoleplayActive, setIsRoleplayActive] = useState(true);

  const handleToggleRoleplay = () => {
    setIsRoleplayActive(!isRoleplayActive);
    toast({
      title: isRoleplayActive ? "Roleplay Disattivato" : "Roleplay Attivato",
      description: `La modalità roleplay è stata ${isRoleplayActive ? 'disattivata' : 'attivata'} con successo.`,
    });
  };

  const handleSendAnnouncement = () => {
    toast({
      title: "Annuncio Inviato",
      description: "L'annuncio è stato inviato a tutti i canali designati.",
    });
  };

  const handleCreatePoll = () => {
    toast({
      title: "Sondaggio Creato",
      description: "Il sondaggio RP è stato creato e pubblicato.",
    });
  };

  const handleEmergencyBroadcast = () => {
    toast({
      title: "Messaggio di Emergenza",
      description: "Il messaggio di emergenza è stato inviato a tutti gli utenti.",
      variant: "destructive",
    });
  };

  return (
    <div className="space-y-6">
      {/* Quick Actions */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Azioni Rapide</h3>
        <div className="space-y-3">
          <Button 
            onClick={handleToggleRoleplay}
            className="w-full discord-btn"
          >
            <Drama className="w-4 h-4 mr-2" />
            {isRoleplayActive ? 'Disattiva' : 'Attiva'} RP
          </Button>
          
          <Button 
            onClick={handleSendAnnouncement}
            className="w-full bg-green-500 hover:bg-green-600 text-white"
          >
            <Megaphone className="w-4 h-4 mr-2" />
            Invia Annuncio
          </Button>
          
          <Button 
            onClick={handleCreatePoll}
            className="w-full bg-yellow-500 hover:bg-yellow-600 text-white"
          >
            <BarChart3 className="w-4 h-4 mr-2" />
            Crea Sondaggio RP
          </Button>
          
          <Button 
            onClick={handleEmergencyBroadcast}
            className="w-full bg-red-500 hover:bg-red-600 text-white"
          >
            <AlertTriangle className="w-4 h-4 mr-2" />
            Messaggio Emergenza
          </Button>
        </div>
      </div>

      {/* Server Stats */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Statistiche Server</h3>
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-600">Uptime Bot</span>
            <span className="text-sm font-medium text-gray-900">99.8%</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-600">CPU Usage</span>
            <span className="text-sm font-medium text-gray-900">23%</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-600">RAM Usage</span>
            <span className="text-sm font-medium text-gray-900">1.2GB / 4GB</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-600">Database Size</span>
            <span className="text-sm font-medium text-gray-900">45.3MB</span>
          </div>
          
          <div className="pt-2 border-t border-gray-100">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Connessioni DB</span>
              <div className="flex items-center space-x-1">
                <div className="status-online"></div>
                <span className="text-sm font-medium text-green-600">Stabile</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Performance Metrics */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Metriche Performance</h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Activity className="w-4 h-4 text-blue-600" />
              <span className="text-sm text-gray-600">Comandi/min</span>
            </div>
            <span className="text-sm font-medium text-gray-900">127</span>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <TrendingUp className="w-4 h-4 text-green-600" />
              <span className="text-sm text-gray-600">Risposta Media</span>
            </div>
            <span className="text-sm font-medium text-gray-900">45ms</span>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Database className="w-4 h-4 text-purple-600" />
              <span className="text-sm text-gray-600">Query DB/sec</span>
            </div>
            <span className="text-sm font-medium text-gray-900">892</span>
          </div>
        </div>
      </div>
    </div>
  );
}
