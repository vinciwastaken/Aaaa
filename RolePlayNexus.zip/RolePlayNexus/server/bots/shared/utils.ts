import { Client, EmbedBuilder, REST, Routes } from 'discord.js';

export function createErrorEmbed(message: string): EmbedBuilder {
  return new EmbedBuilder()
    .setColor(0xe74c3c)
    .setTitle('❌ Errore')
    .setDescription(message)
    .setTimestamp();
}

export function createSuccessEmbed(message: string): EmbedBuilder {
  return new EmbedBuilder()
    .setColor(0x2ecc71)
    .setTitle('✅ Successo')
    .setDescription(message)
    .setTimestamp();
}

export function createWarningEmbed(message: string): EmbedBuilder {
  return new EmbedBuilder()
    .setColor(0xf39c12)
    .setTitle('⚠️ Attenzione')
    .setDescription(message)
    .setTimestamp();
}

export function createInfoEmbed(title: string, message: string): EmbedBuilder {
  return new EmbedBuilder()
    .setColor(0x3498db)
    .setTitle(`ℹ️ ${title}`)
    .setDescription(message)
    .setTimestamp();
}

export async function registerCommands(client: Client, commands: any[], token: string) {
  const rest = new REST({ version: '10' }).setToken(token);
  
  try {
    console.log(`🔄 Registrando ${commands.length} comandi slash...`);

    await rest.put(
      Routes.applicationCommands(client.user?.id || ''),
      { body: commands.map(command => command.toJSON()) }
    );

    console.log(`✅ Registrati ${commands.length} comandi slash con successo.`);
  } catch (error) {
    console.error('❌ Errore nella registrazione dei comandi:', error);
  }
}

export function formatDate(date: Date): string {
  return date.toLocaleDateString('it-IT', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('it-IT', {
    style: 'currency',
    currency: 'EUR'
  }).format(amount);
}

export function generateTicketId(): string {
  return `TK-${Date.now().toString().slice(-6)}`;
}

export function validateDiscordId(id: string): boolean {
  return /^\d{17,19}$/.test(id);
}

export function validatePlate(plate: string): boolean {
  // Italian license plate format validation
  return /^[A-Z]{2}\d{3}[A-Z]{2}$/.test(plate.toUpperCase());
}

export function getJobEmoji(job: string): string {
  const jobEmojis: { [key: string]: string } = {
    'poliziotto': '👮‍♂️',
    'medico': '👨‍⚕️',
    'pompiere': '👨‍🚒',
    'meccanico': '🔧',
    'camionista': '🚛',
    'chef': '👨‍🍳',
    'insegnante': '👨‍🏫',
    'giornalista': '📰',
    'avvocato': '⚖️',
    'cittadino': '👤'
  };
  
  return jobEmojis[job] || '👤';
}

export function getDrugEmoji(drug: string): string {
  const drugEmojis: { [key: string]: string } = {
    'marijuana': '🌿',
    'cocaina': '❄️',
    'eroina': '💉',
    'metanfetamine': '🧪',
    'ecstasy': '💊'
  };
  
  return drugEmojis[drug] || '💊';
}

export function getCrimeTypeEmoji(crimeType: string): string {
  const crimeEmojis: { [key: string]: string } = {
    'furto': '🏃‍♂️',
    'rapina': '🔫',
    'traffico_droga': '💊',
    'omicidio': '💀',
    'aggressione': '👊',
    'guida_in_stato_di_ebbrezza': '🍺',
    'eccesso_di_velocita': '🚗',
    'altro': '⚠️'
  };
  
  return crimeEmojis[crimeType] || '⚠️';
}

export function logBotActivity(botName: string, action: string, details?: any) {
  const timestamp = new Date().toISOString();
  console.log(`[${timestamp}] [${botName}] ${action}`, details ? JSON.stringify(details) : '');
}
